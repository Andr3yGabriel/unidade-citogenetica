require('ts-node/register');
const config = require('./config.ts');

module.exports = config;