import UserRepository from './UserRepository';
import ExamRepository from './ExamRepository';
import ReportRepository from './ReportRepository';

export {
    UserRepository,
    ExamRepository,
    ReportRepository
};