module.exports = {
    UserController: require('./UserController'),
    ExamController: require('./ExamController'),
    ReportController: require('./ReportController'),
    AuthController: require('./AuthController'),
    AdminController: require('./AdminController')
}